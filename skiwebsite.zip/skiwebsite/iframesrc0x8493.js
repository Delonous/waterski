$(window).on('load', function () {
    document.getElementById('iSlalom').src = 'https://www.youtube.com/embed/7Necm9_6wrs';
    document.getElementById('iTrick').src = 'https://www.youtube.com/embed/3Og3B_E2HrY';
    document.getElementById('iJump').src = 'https://www.youtube.com/embed/t4ZGKI8vpcg';
    document.getElementById('iMSU').src = 'https://www.youtube.com/embed/lrewJcxQeSk';
 });